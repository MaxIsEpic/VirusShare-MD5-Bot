﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;


namespace MD5Bot
{
    class Program
    {
        static void Main(string[] args)
        {
            //ServicePointManager.SecurityProtocol = (SecurityProtocolType)3072; // ENABLE THIS IF YOU GET A SSL/TLS SECURE CHANNEL ERROR
            WebClient w = new WebClient();
            string path = @"C:\Users\USERNAME\Desktop\HASHDIRECTORY\"; //Replace username with your username and the directory with the folder you wanna download the hashes too
            int num = 00000; //Change this number to the file you wanna start from, 00000 stars from the first file, Do 00001 if you wanna start from 1, or 00100 if you wanna do the 100th one
            int max = 372; // Change this number to the point you wanna stop at +1, So if you wanna stop at list 300, do 301. Etc
            while (num < max)
            {
                w.DownloadFile("https://virusshare.com/hashes/VirusShare_" + num + ".md5", path + "VirusShare_" + num + ".md5.txt");
                Console.WriteLine("Downloaded File " + num + " of " + max);
                num++;
            }
        }
    }
}
